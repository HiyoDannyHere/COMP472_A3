import source.NaiveBayes as nb

nb.a3_start()