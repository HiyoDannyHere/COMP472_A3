# COMP472_A3
Assignment 3 for COMP 472 Artificial Intelligence<br />

* Adam Yafout (40040306)
* Daniel Thibault-Shea (40073133)

Repository: https://github.com/HiyoDannyHere/COMP472_A3.git

###Instructions <br />
**Preconditions**: 
<ul>
    <li>Each data file must have header: tweet_id	text	q1_label	q2_label	q3_label	q4_label	q5_label	q6_label	q7_label</li>
    <li>All input datafiles (training/test) must be in the "data/" directory</li>
    <li>Need python packages :
        <ul>
            <li>pandas</li>
            <li>math</li>
        </ul>
    </li>
</ul>

**Running**: Just run main file and everything should work! <br/>
**Data**: output files are in "./output". LSTM files were made offline but other are generated each time.



